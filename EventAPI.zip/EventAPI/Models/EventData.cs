﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EventAPI.Models
{
    [Table("Events")]
    public class EventData
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public int Id { get; set; }
        [Required, StringLength(50)]
        [Column("title")]
        public string Title { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [DataType(DataType.DateTime)]
        [Column("startdate")]
        public DateTime StartDate { get; set; }
        [DataType(DataType.DateTime)]
        [Column("enddate")]
        public DateTime EndDate { get; set; }
        [Required, StringLength(50)]
        [Column("location")]
        public string Location { get; set; }
        [DataType(DataType.Url)]
        [Required, StringLength(250)]
        [Column("reg_url")]
        public string RegistrationUrl { get; set; }
        [Required, StringLength(50)]
        [Column("organizer")]
        public string Organizer { get; set; }
        [DataType(DataType.DateTime)]
        [Column("last_reg_date")]
        public DateTime LastDate { get; set; }

    }
}
