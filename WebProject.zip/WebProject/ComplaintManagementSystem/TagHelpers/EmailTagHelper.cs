﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ComplaintManagementSystem.TagHelpers
{
    public class EmailTagHelper:TagHelper
    {
        [HtmlAttributeName("mail-to")]
        public string Email { get; set; }

        [HtmlAttributeNotBoundAttribute]
        public string Dummy { get; set; }
        //public override void Process(TagHelperContext context, TagHelperOutput output)
        //{
        //    //base.Process(context, output);
        //    output.TagName = "a";
        //    output.Attributes.Add("href", "mailto:rajaayyanar008@gmail.com");
        //    output.TagMode = TagMode.StartTagAndEndTag;
        //    output.Content.SetContent($"Click to send email to {Email}");
        //}
        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            var childContent = await output.GetChildContentAsync();
            var innerContent = childContent.GetContent();
            //base.Process(context, output);
            output.TagName = "a";
            output.Attributes.Add("href", "mailto:rajaayyanar008@gmail.com");
            output.TagMode = TagMode.StartTagAndEndTag;
            output.Content.SetHtmlContent($"Click to send email to {Email}");
        }
    }
}
