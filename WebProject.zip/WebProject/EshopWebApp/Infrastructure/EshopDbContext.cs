﻿using EshopWebApp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EshopWebApp.Infrastructure
{
    public class EshopDbContext:DbContext
    {
        public EshopDbContext(DbContextOptions<EshopDbContext> options):base(options)
        {

        }
        public DbSet<CatalogItem> CatalogItems { get; set; }

    }
}
