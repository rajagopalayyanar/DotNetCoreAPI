﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EshopWebApp.Infrastructure;
using EshopWebApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace EshopWebApp.Controllers
{
    [Route("products")]
    public class CatalogController : Controller
    {
        private EshopDbContext db;

        public CatalogController(EshopDbContext dbContext)
        {
            this.db = dbContext;
        }
        [Route("list", Name ="ListProducts")]
        public IActionResult Index()
        {
            var products = db.CatalogItems.ToList();
            return View(products);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateAsync(CatalogItem item)
        {
            if (ModelState.IsValid)
            {
                await db.CatalogItems.AddAsync(item);
                await db.SaveChangesAsync();
                return RedirectToAction("list");
            }
            return View(item);
        }

        [HttpGet,Route("detail/id",Name="ProductDetail")]
        public async Task<IActionResult> DetailAsync(int id)
        {
            var item = await db.CatalogItems.FindAsync(id);
            return View(item);
        }
    }
}