﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventAPI.Infrastructure;
using EventAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EventAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : Controller
    {
        private EventDbContext db;
        public EventsController(EventDbContext dbContext)
        {
            db = dbContext;
        }
        [HttpGet("",Name="GetAllEvents")]
        public ActionResult<IEnumerable<EventData>> GetEvents()
        {
            var events = db.Events.ToList();
            return Ok(events);
        }
        [HttpGet("{id:int:min(1)}", Name = "GetEventById")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<EventData>> GetEventByIdAsync(int id)
        {
            var events = await db.Events.FindAsync(id);
            if (events == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(events);
            }
        }

        //[HttpPost("",Name="AddEvent")]
        //public ActionResult<EventData> AddEvent(EventData item)
        //{
        //    TryValidateModel(item);
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    else
        //    {
        //        db.Events.Add(item);
        //        db.SaveChanges();
        //        return Created("", item);
        //    }
        //}
        [HttpPost("", Name = "AddEvent")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<EventData>> AddEventAsync(EventData item)
        {
            TryValidateModel(item);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                await db.Events.AddAsync(item);
                await db.SaveChangesAsync();
                return CreatedAtRoute("GetEventById", new { id = item.Id },item);
            }
        }
        [HttpPut("{id:int:min(1)}", Name="UpdateEvent")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<EventData>> UpdateEventAsync(int id, EventData data)
        {
            var item = await db.Events.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            TryValidateModel(data);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                item.Title = data.Title;
                item.Description = data.Description;
                item.StartDate = data.StartDate;
                item.EndDate = data.EndDate;
                item.RegistrationUrl = data.RegistrationUrl;
                item.Location = data.Location;
                item.LastDate = data.LastDate;
                item.Organizer = data.Organizer;
                await db.SaveChangesAsync();
                return Ok(data);
            }
        }
        [HttpDelete("{id:int:min(1)}", Name = "DeleteEvents")]
        public async Task<ActionResult> DeleteEventAsync(int id)
        {
            var data2 = await db.Events.FindAsync(id);
            if (data2 == null)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                db.Events.Remove(data2);

                await db.SaveChangesAsync();
                return NoContent();
            }
        }
    }
}